# Market Sentiment Analyzer

A browser-viewable market sentiment dashboard with a small Python backend for live data.

## Deploy on Streamlit Cloud

Use:

```text
Main file path: streamlit_app.py
```

Streamlit Cloud will install dependencies from `requirements.txt`.

## View locally

Run the live server:

```bash
python3 server.py
```

Then open:

```text
http://127.0.0.1:8010/
```

Do not open `index.html` directly for the live version. The page needs the `/api/analyze` backend route from `server.py`.

## Files

- `index.html` - dashboard markup
- `styles.css` - dark finance terminal styling
- `script.js` - API-driven chart rendering, filters, and interactivity
- `server.py` - live Yahoo Finance and Google News RSS backend
