from __future__ import annotations

from server import company_info, filter_by_lookback, google_news


def get_company_info(ticker: str) -> dict:
    info = company_info(ticker.upper())
    return {
        "name": info.get("name", ticker.upper()),
        "sector": info.get("sector", "Public Equity"),
        "market_cap": info.get("marketCap"),
    }


def fetch_all_news(ticker: str, company_name: str = "", max_total: int = 40) -> list[dict]:
    name = company_name or get_company_info(ticker).get("name", ticker)
    return google_news(ticker.upper(), name, max_total)

