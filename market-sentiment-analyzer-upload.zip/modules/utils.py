from __future__ import annotations

import streamlit as st

SENTIMENT_COLORS = {
    "Bullish": "#00C896",
    "Bearish": "#FF4B6E",
    "Neutral": "#94A3B8",
}


def format_large_number(value) -> str:
    if value is None:
        return "N/A"
    if isinstance(value, str):
        return value
    value = float(value)
    for divisor, suffix in ((1_000_000_000_000, "T"), (1_000_000_000, "B"), (1_000_000, "M")):
        if abs(value) >= divisor:
            return f"${value / divisor:.2f}{suffix}"
    return f"${value:,.0f}"


def score_to_color(score: float) -> str:
    if score > 0.05:
        return SENTIMENT_COLORS["Bullish"]
    if score < -0.05:
        return SENTIMENT_COLORS["Bearish"]
    return SENTIMENT_COLORS["Neutral"]


def clear_cache() -> None:
    st.cache_data.clear()

