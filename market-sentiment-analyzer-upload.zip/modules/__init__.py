"""Compatibility modules for the original Streamlit app entry point."""

