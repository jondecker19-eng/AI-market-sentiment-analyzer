from __future__ import annotations

from server import company_info, reddit_posts


def fetch_reddit_posts(ticker: str, max_per_subreddit: int = 8) -> list[dict]:
    info = company_info(ticker.upper())
    return reddit_posts(ticker.upper(), info.get("name", ticker), max_per_subreddit * 4)

