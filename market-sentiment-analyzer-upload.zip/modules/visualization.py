from __future__ import annotations

from collections import Counter

import pandas as pd
import plotly.graph_objects as go


def _dark(fig: go.Figure) -> go.Figure:
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="#161B22",
        plot_bgcolor="#161B22",
        font_color="#E6EDF3",
        margin=dict(l=20, r=20, t=45, b=25),
    )
    return fig


def sentiment_gauge(score: float, ticker: str) -> go.Figure:
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=score,
        number={"valueformat": "+.3f"},
        title={"text": f"{ticker.upper()} Sentiment"},
        gauge={
            "axis": {"range": [-1, 1]},
            "bar": {"color": "#F0B429"},
            "steps": [
                {"range": [-1, -0.05], "color": "#FF4B6E"},
                {"range": [-0.05, 0.05], "color": "#94A3B8"},
                {"range": [0.05, 1], "color": "#00C896"},
            ],
        },
    ))
    return _dark(fig)


def sentiment_distribution(stats: dict) -> go.Figure:
    labels = ["Bullish", "Neutral", "Bearish"]
    values = [
        stats.get("bullish_count", stats.get("bullish", 0)),
        stats.get("neutral_count", stats.get("neutral", 0)),
        stats.get("bearish_count", stats.get("bearish", 0)),
    ]
    fig = go.Figure(go.Bar(
        x=values,
        y=labels,
        orientation="h",
        marker_color=["#00C896", "#94A3B8", "#FF4B6E"],
    ))
    fig.update_layout(title="Signal Distribution")
    return _dark(fig)


def source_breakdown(items: list[dict]) -> go.Figure:
    counts = Counter(item.get("kind") or item.get("source") or "Unknown" for item in items)
    fig = go.Figure(go.Pie(labels=list(counts), values=list(counts.values()), hole=0.45))
    fig.update_layout(title="Source Breakdown")
    return _dark(fig)


def sentiment_vs_price(items: list[dict], price_df: pd.DataFrame, ticker: str) -> go.Figure:
    fig = go.Figure()
    if not price_df.empty and "Close" in price_df:
        fig.add_trace(go.Scatter(x=price_df.index, y=price_df["Close"], name="Close", line_color="#58A6FF"))
    if items:
        avg = sum(float(item.get("score", 0)) for item in items) / len(items)
        fig.add_trace(go.Scatter(x=price_df.index if not price_df.empty else [0], y=[avg] * max(1, len(price_df)), name="Sentiment", line_color="#F0B429", yaxis="y2"))
    fig.update_layout(title=f"{ticker.upper()} Sentiment vs Price", yaxis2=dict(overlaying="y", side="right", range=[-1, 1]))
    return _dark(fig)


def sentiment_heatmap(items: list[dict]) -> go.Figure:
    by_label = Counter(item.get("label", "Neutral") for item in items)
    fig = go.Figure(go.Heatmap(
        z=[[by_label.get("Bullish", 0), by_label.get("Neutral", 0), by_label.get("Bearish", 0)]],
        x=["Bullish", "Neutral", "Bearish"],
        y=["Live items"],
        colorscale=[[0, "#FF4B6E"], [0.5, "#94A3B8"], [1, "#00C896"]],
    ))
    fig.update_layout(title="Sentiment Heatmap")
    return _dark(fig)


def top_keywords(items: list[dict]) -> go.Figure:
    words = []
    for item in items:
        words.extend(word.lower() for word in item.get("title", "").split() if len(word) > 4)
    counts = Counter(words).most_common(12)
    fig = go.Figure(go.Bar(x=[word for word, _ in counts], y=[count for _, count in counts], marker_color="#F0B429"))
    fig.update_layout(title="Top Keywords")
    return _dark(fig)


def multi_stock_radar(results: dict[str, dict]) -> go.Figure:
    labels = list(results)
    values = [results[sym].get("aggregate_score", results[sym].get("aggregateScore", 0)) for sym in labels]
    if labels:
        labels.append(labels[0])
        values.append(values[0])
    fig = go.Figure(go.Scatterpolar(r=values, theta=labels, fill="toself", line_color="#00C896"))
    fig.update_layout(title="Multi-stock Comparison", polar=dict(radialaxis=dict(range=[-1, 1])))
    return _dark(fig)

