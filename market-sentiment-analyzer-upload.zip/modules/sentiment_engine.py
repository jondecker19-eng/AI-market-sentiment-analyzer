from __future__ import annotations

from server import aggregate, keywords, score_text


def analyze_items(items: list[dict]) -> list[dict]:
    analysed = []
    for item in items:
        current = dict(item)
        if "score" not in current or "label" not in current:
            score, label = score_text(current.get("title", ""))
            current["score"] = score
            current["label"] = label
        analysed.append(current)
    return analysed


def compute_aggregate_score(items: list[dict]) -> dict:
    stats = aggregate(items)
    return {
        "total": stats["total"],
        "aggregate_score": stats["aggregateScore"],
        "bullish_count": stats["bullish"],
        "bearish_count": stats["bearish"],
        "neutral_count": stats["neutral"],
        "dominant_label": stats["dominant"],
    }


def generate_ai_summary(ticker: str, items: list[dict]) -> str:
    stats = aggregate(items)
    top = keywords(items, limit=5)
    keyword_text = ", ".join(top) if top else "the latest headlines"
    return (
        f"{ticker.upper()} sentiment is {stats['dominant'].lower()} based on "
        f"{stats['total']} live items. Aggregate score is {stats['aggregateScore']:+.3f}, "
        f"with {stats['bullish']} bullish, {stats['bearish']} bearish, and "
        f"{stats['neutral']} neutral signals. Discussion is clustering around {keyword_text}."
    )

